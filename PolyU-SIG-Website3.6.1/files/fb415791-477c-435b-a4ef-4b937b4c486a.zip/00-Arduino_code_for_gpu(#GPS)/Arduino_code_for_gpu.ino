#include <TinyGPS++.h>
#include <ButtonDebounce.h>
#include <neotimer.h>      // Timer interrupt driver
#include <WiFi.h>          // 8266 Wifi driver
#include <PubSubClient.h>  // MQTT server library
#include <ArduinoJson.h>   // JSON library
#include <SoftwareSerial.h>
#include <LiquidCrystal_I2C.h>  // I2C LCD driver
#include <Wire.h>               // Arduino I2C
#define KEY 16

//const char *ssid = "EIA-W311MESH";
//const char *password = "42004200";
const char* ssid = "NingNing00";
const char* password = "c1ning@yahoo.com.hk";
//const char *mqtt_server = "mqtt.eclipse.org"; // MQTT server name
const char* mqtt_server = "test.mosquitto.org";  // MQTT server name
char* mqttTopic = "ASE_FYP_GPU";                 // MQTT topic

TinyGPSPlus gps;
SoftwareSerial GPSswSer1;

Neotimer mytimer(1000);  // Set timer interrupt to 1s
WiFiClient espClient;
PubSubClient client(espClient);  // Open an MQTT client

ButtonDebounce button(KEY, 100);

// Set the LCD I2C address, lines and rows
LiquidCrystal_I2C lcd(0x27, 20, 4);  // LCD module I2C address = 0x27, 20 chars x 4 lines

// Key debounce set-up
//Bounce key_debounce = Bounce(); // Instantiate a Bounce object


// Software serial set-up
//SoftwareSerial SSerial(14, 12, false, 128); //RX = pin14, TX = pin12


void displayInfo() {
  Serial.print(F("Location: "));
  if (gps.location.isValid()) {
    Serial.print(gps.location.lat(), 6);
    Serial.print(F(","));
    Serial.print(gps.location.lng(), 6);
    lcd.setCursor(0, 2);
    lcd.print("Locate:");
    lcd.print(gps.location.lat(), 2);
    lcd.print(F(","));
    lcd.print(gps.location.lng(), 2);
  }

  else {
    Serial.print(F("INVALID"));
  }
  Serial.println(" ");
}


boolean sys_status = LOW;
char msg[200];
int value = 0;
int prev_value = 0;
String ipAddress;
String macAddr;
String recMsg = "";

StaticJsonDocument<200> Jsondata;  // Create a JSON document of 200 characters max

void buttonChanged(int state) {
  if (digitalRead(KEY) == 0) {
    sys_status = !sys_status;
  }
  Serial.println("PRESSED");
}

//Set up the Wifi connection
void setup_wifi() {

  delay(100);
  // We start by connecting to a WiFi network
  Serial.printf("\nConnecting to %s\n", ssid);
  WiFi.begin(ssid, password);  // start the Wifi connection with defined SSID and PW

  // Indicate "......" during connecting
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  // Show "WiFi connected" once linked
  Serial.printf("\nWiFi connected\n");

  // Show IP address and MAC address
  ipAddress = WiFi.localIP().toString();
  Serial.printf("\nIP address: %s\n", ipAddress.c_str());
  macAddr = WiFi.macAddress();
  Serial.printf("MAC address: %s\n", macAddr.c_str());
}

// Routine to receive message from MQTT server
void callback(char* topic, byte* payload, unsigned int length) {

  recMsg = "";
  for (int i = 0; i < length; i++) {
    recMsg = recMsg + (char)payload[i];
  }
  Serial.printf("%d: Message arrived [%s] %s\n", millis(), topic, recMsg.c_str());

  /*DeserializationError error = deserializeJson(jsonBuffer, recMsg);

  if (error) {
    Serial.print(F("deserializeJson() failed: "))
    Serial.println(error.c_str());
    return;
  }*/
  //delay(500);
}

void reconnect() {
  // Loop until we're reconnected
  while (!client.connected()) {
    Serial.printf("Attempting MQTT connection...");
    // Attempt to connect
    //if (client.connect("ESP8266Client")) {
    if (client.connect(macAddr.c_str())) {
      Serial.println("Connected");
      // Once connected, publish an announcement...
      snprintf(msg, 75, "EiA IoT Traffic Light (%s) is READY", ipAddress.c_str());
      client.subscribe(mqttTopic);
      delay(1000);
      client.publish(mqttTopic, msg);
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      // Wait 5 seconds before retrying
      delay(5000);
    }
  }
}

void status_change() {
  sys_status = !sys_status;  // Toggle system status
}


void setup() {

  GPSswSer1.begin(9600, SWSERIAL_8N1, 14, 12);  //14rx 12tx

  button.setCallback(buttonChanged);


  pinMode(KEY, INPUT_PULLUP);

  Serial.println("Delay 0.5s!");
  delay(500);

  Serial.begin(115200);

  setup_wifi();
  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);


  //Initalize Json message
  Jsondata["GPU1_SYSTEM_STATUS"] = "Idle";  // Initiate name "status"
  Jsondata["GPU1ELECTRICITY"] = 0;          // Initiate name "meter"




  //key_debounce.attach(KEY,INPUT_PULLUP); // Attach the debouncer to a pin with INPUT_PULLUP mode
  //key_debounce.interval(50); // Use a debounce interval in msec

  lcd.begin();  // init the LCD

  // Flash for 3 times upon start-up
  for (int i = 0; i < 3; i++) {
    lcd.backlight();  // Backlight enable
    delay(250);
    lcd.noBacklight();  // Backlight enable
    delay(250);
  }
  lcd.backlight();

  //Initialization
  lcd.setCursor(0, 0);  // 1st line beginning
  lcd.print("IOT SYSTEM");
  delay(1000);
  lcd.setCursor(0, 1);  // 2nd line beginning
  lcd.print("POLYU-IC");
  delay(2000);
  lcd.setCursor(0, 2);
  lcd.print("d77");
  delay(3000);

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Ground Power Unit 1");
  lcd.setCursor(0, 1);
  lcd.print("Status:Idle ");
  //lcd.setCursor(0, 2);
  //lcd.print("Lat:22.30 Long:114.1");
  //lcd.print("Locate:");
  //lcd.print(gps.location.lat(), 3);
  //lcd.print(F(","));
  //lcd.print(gps.location.lng(), 3);
  lcd.setCursor(0, 3);
  lcd.print("Electricity:");
  lcd.setCursor(17, 3);
  lcd.print("kwh");


  //attachInterrupt(digitalPinToInterrupt(KEY), status_change, FALLING);
}

void loop() {


  while (GPSswSer1.available() > 0)
    if (gps.encode(GPSswSer1.read()))
      displayInfo();


  button.update();


  value = analogRead(A0) * 100 / 1024;
  //Serial.println(value);
  if (value != prev_value) {
    Jsondata["GPU1ELECTRICITY"] = value;

    // Packing the JSON message into msg
    serializeJson(Jsondata, Serial);
    serializeJson(Jsondata, msg);

    // Publish the msg to MQTT server
    client.publish(mqttTopic, msg);

    // Store as previous value
    prev_value = value;
  }

  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  /* Check the software serial
   while (SSerial.available() > 0) {
     SSerial.write(SSerial.read());
   }*/

  lcd.setCursor(12, 3);  // LCD Position11, 1st line
  lcd.print(value);      // Print the meter value to LCD
  lcd.print(" ");        // Always clear the digit after the last digit
  delay(100);

  //Use Timer Interrupt to repeat the following task regularly
  if (mytimer.repeat()) {
    if (sys_status == LOW) {
      lcd.setCursor(7, 1);
      lcd.print("Idle  ");

      // Set the value of the names of JSON message property
      Jsondata["GPU1_SYSTEM_STATUS"] = "Idle";
      Jsondata["GPU1ELECTRICITY"] = value;
      Jsondata["GPU1_LATITUDE"] = gps.location.lat(), 6;
      Jsondata["GPU1_LONGITUDE"] = gps.location.lng(), 6;



      // Jsondata["LOCATION"] = gps.location.lat(), 6 , gps.location.lng(), 6;

      // Packing the JSON message into msg
      serializeJson(Jsondata, Serial);
      serializeJson(Jsondata, msg);

      //snprintf(msg, 75, "System is idle, Analog value = %d", value);
      //client.subscribe(mqttTopic);
      //delay(1000);

      //Publish msg to MQTT server
      client.publish(mqttTopic, msg);
    } else {
      lcd.setCursor(7, 1);
      lcd.print("Active");

      // Set the value of the names of JSON message property
      Jsondata["GPU1_SYSTEM_STATUS"] = "Active";
      Jsondata["GPU1ELECTRICITY"] = value;
      Jsondata["GPU1_LATITUDE"] = gps.location.lat(), 6;
      Jsondata["GPU1_LONGITUDE"] = gps.location.lng(), 6;



      // Jsondata["LOCATION"] = gps.location.lat(), 6 , gps.location.lng(), 6;

      // Packing the JSON message into msg
      serializeJson(Jsondata, Serial);
      serializeJson(Jsondata, msg);

      //snprintf(msg, 75, "System is Active, Analog value = %d", value);
      //client.subscribe(mqttTopic);
      //delay(1000);

      //Publish msg to MQTT server
      client.publish(mqttTopic, msg);
    }
  }
}
